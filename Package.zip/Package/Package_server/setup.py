from distutils.core import setup

setup(name='package_server',
      version='1.0.3',
      description='Server program for eYRC+ 2015',
      author='Sanam Shakya, Sudeep Rajput',
      py_modules=['package_server'])
