from distutils.core import setup

setup(name='package_client',
      version='1.0.2',
      description='Client program for eYRC+ 2015',
      author=' Sudeep Rajput',
      py_modules=['package_client'])
